"""Pure immutable command tables. Labels never become internal state."""
from .ui_text import text
CONNECTION = (
    ('connection.configure', 'configure'), ('connection.connect', 'connect'),
    ('connection.refresh', 'refresh'), ('connection.status', 'connection_status'),
    ('connection.disconnect', 'disconnect'), ('connection.settings', 'connection_settings'),
    ('connection.storage', 'storage_title'),
)
SETTINGS = (*CONNECTION, ('connection.diagnostics', 'connection_diagnostics'))
PROGRAMME = (
    ('programme.preview', 'preview'), ('programme.saved', 'saved_series'),
    ('programme.prepare', 'prepare_pass'), ('programme.status', 'pass_status'),
    ('programme.history', 'operation_history'),
)
DEVELOPER = (
    ('demo.open', 'open_demo'), ('demo.close', 'close_demo'),
    ('demo.status', 'demo_status'), ('demo.stress', 'demo_stress'),
    ('demo.exercise', 'demo_exercise'), ('diagnostic.index', 'index_status'),
    ('diagnostic.timing', 'timing'), ('diagnostic.connection', 'connection_diagnostics'),
)
GROUP_KEYS = {'All': 'all_channels', 'Visible': 'visible_channels', 'Favorites': 'favourites',
              'Guide station unqualified': 'station_unavailable', 'Guide station missing': 'station_blank',
              'General': 'general', 'Empty': 'empty_collection'}


def command(entries, answer):
    return entries[answer][0] if type(answer) is int and 0 <= answer < len(entries) else None


def select(dialog, strings, heading, entries):
    # Capture before opening the modal, which may reenter settings/window logic.
    captured = tuple(entries)
    return command(captured, dialog.select(text(strings, heading), [text(strings, key) for _, key in captured]))


def group_label(strings, group):
    key = GROUP_KEYS.get(group)
    return text(strings, key) if key else group
